/* $Id: multi_c_rehash.c,v 1.4 2005/04/06 13:40:37 shinra Exp $ */
/* vim: set sw=4 sts=4 ts=8: */
#include <stdio.h>
#include <ctype.h>
#include <assert.h>
#include <errno.h>
#include <string.h>

#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>

#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>

/*#define COPY_FILE_USING_STDIO*/
#ifndef CERTDIR
# define CERTDIR "/usr/local/ssl/certs"
#endif
#define OPT_DO_CERTS 1U
#define OPT_DO_CRLS 2U

typedef unsigned long x509hash_type;

typedef enum {
    ERR_NONE = 0,
    ERR_NOMEM,
    ERR_DUPLICATE,
    ERR_DIR_OPEN,
    ERR_BADARG,
    ERR_DUMMY_
} err_type;

typedef struct tagPtrArray {
    size_t pa_size;
    size_t pa_capacity;
    void **pa_body;
} PtrArray;

err_type PtrArray_new(PtrArray **obj_ret);
void PtrArray_delete(PtrArray *obj);
err_type PtrArray_reserve(PtrArray *obj, size_t required);
err_type PtrArray_add(PtrArray *obj, void *ptr);

err_type
PtrArray_new(PtrArray **obj_ret)
{
    PtrArray *obj = *obj_ret = (PtrArray *)malloc(sizeof(PtrArray));
    if (!obj) return ERR_NOMEM;
    obj->pa_size = obj->pa_capacity = 0;
    obj->pa_body = NULL;
    return ERR_NONE;
}

void
PtrArray_delete(PtrArray *obj)
{
    if (!obj) return;
    free(obj->pa_body);
    free(obj);
}

err_type
PtrArray_reserve(PtrArray *obj, size_t required)
{
    size_t newcapacity;
    void **newbody;
    if (required <= obj->pa_capacity) return ERR_NONE;
    newcapacity = ((obj->pa_capacity + 1) * 2 > required)
	? ((obj->pa_capacity + 1) * 2) : required;
    newbody = realloc(obj->pa_body, sizeof(void *) * newcapacity);
    if (!newbody) return ERR_NOMEM;
    obj->pa_body = newbody;
    obj->pa_capacity = newcapacity;
    return ERR_NONE;
}

err_type
PtrArray_add(PtrArray *obj, void *ptr)
{
    err_type r;
    if (obj->pa_size < obj->pa_capacity) {
	obj->pa_body[obj->pa_size++] = ptr;
	return ERR_NONE;
    }
    r = PtrArray_reserve(obj, obj->pa_size + 1);
    if (r) return r;
    obj->pa_body[obj->pa_size++] = ptr;
    return ERR_NONE;
}

typedef struct tagHashMaker {
    const char *dirname;
    const char *suffix;
    const char *type;
    err_type (*read_pem_func) (X509_NAME **xn_ret, FILE *fp);

    X509_NAME **xns;
    size_t xns_capacity, n_xns;
} HashMaker;

err_type HashMaker_new(HashMaker **obj_ret,
	const char *dirname, const char *suffix, const char *type,
	err_type (*read_pem_func) (X509_NAME **xn_ret, FILE *fp));
void HashMaker_delete(HashMaker *obj);
err_type HashMaker_hash_file(HashMaker *obj, const char *fbase);
err_type HashMaker_register_x509_name(HashMaker *obj,
	X509_NAME *xn, size_t *coll_count_ret, x509hash_type *hash_ret);

int copy_file(const char *src, const char *dst);

err_type
HashMaker_new(HashMaker **obj_ret,
	const char *dirname, const char *suffix, const char *type,
	err_type (*read_pem_func) (X509_NAME **xn_ret, FILE *fp))
{
    HashMaker *obj = *obj_ret = (HashMaker *)malloc(sizeof(HashMaker));
    if (!obj) return ERR_NOMEM;
    obj->dirname = dirname;
    obj->suffix = suffix;
    obj->type = type;
    obj->read_pem_func = read_pem_func;
    obj->xns = NULL;
    obj->xns_capacity = obj->n_xns = 0;
    return ERR_NONE;
}

void
HashMaker_delete(HashMaker *obj)
{
    size_t i;
    if (!obj) return;
    for (i = 0; i < obj->xns_capacity; ++i)
	if (obj->xns[i])
	    X509_NAME_free(obj->xns[i]);
    free(obj->xns);
    free(obj);
}

err_type
HashMaker_register_x509_name(HashMaker *obj,
	X509_NAME *xn, size_t *coll_count_ret, x509hash_type *hash_ret)
{
    err_type retval = ERR_NONE;
    x509hash_type hash = X509_NAME_hash(xn);
    const unsigned int FACTOR = 8;
    size_t i, j;
    size_t coll_count = 0;

    if ((obj->n_xns + 1) * FACTOR > obj->xns_capacity) {
#ifndef _NDEBUG
	size_t rehash_count = 0;
#endif
	size_t newcapacity = (obj->n_xns + 1) * 2 * FACTOR;
	X509_NAME **newxns = (X509_NAME **)calloc(
		newcapacity, sizeof(X509_NAME *));

	if (!newxns) {
	    retval = ERR_NOMEM;
	    goto last;
	}
	for (i = 0; i < obj->xns_capacity; ++i) {
	    x509hash_type hh;
	    if (!obj->xns[i]) continue;
#ifndef _NDEBUG
	    ++rehash_count;
#endif
	    hh = X509_NAME_hash(obj->xns[i]);
	    j = (size_t)hh % newcapacity;
	    while (newxns[j]) {
		++j;
		if (j == newcapacity) j = 0;
	    }
	    newxns[j] = obj->xns[i];
	}
	assert(rehash_count == obj->n_xns);
	free(obj->xns);
	obj->xns = newxns;
	obj->xns_capacity = newcapacity;
    }

    j = (size_t)hash % obj->xns_capacity;
    while (obj->xns[j]) {
	x509hash_type hash2 = X509_NAME_hash(obj->xns[j]);
	if (hash == hash2) {
	    if (X509_NAME_cmp(xn, obj->xns[j]) == 0) {
		retval = ERR_DUPLICATE;
		goto last;
	    } else {
		++coll_count;
	    }
	}
	++j;
	if (j == obj->xns_capacity) j = 0;
    }
    obj->xns[j] = xn;
    ++obj->n_xns;
    if (coll_count_ret) *coll_count_ret = coll_count;
    if (hash_ret) *hash_ret = hash;
last:
    return retval;
}

err_type
HashMaker_hash_file(HashMaker *obj, const char *fbase)
{
    err_type retval = ERR_NONE;
    char *fpath = NULL;
    size_t fpathmax;
    FILE *fp = NULL;
    X509_NAME *xn;

    fpathmax = strlen(obj->dirname) + 1 + strlen(fbase) + 1;
    fpath = (char *)malloc(fpathmax);
    if (!fpath) {
	retval = ERR_NOMEM;
	goto last;
    }
    BIO_snprintf(fpath, fpathmax, "%s/%s", obj->dirname, fbase);

    fp = fopen(fpath, "r");
    if (!fp) {
	perror(fpath);
	goto last;
    }

    while ((retval = obj->read_pem_func(&xn, fp)) == ERR_NONE && xn) {
	size_t coll_count;
	x509hash_type hash;
	err_type r;
	char *linkpath = NULL;
	size_t linkpathmax;
	const char *linkbase;
	
	r = HashMaker_register_x509_name(obj, xn, &coll_count, &hash);
	if (r == ERR_DUPLICATE) {
	    fprintf(stderr,
		    "WARNING: Skiping duplicate %s %s\n", obj->type, fbase);
	    X509_NAME_free(xn);
	    continue;
	} else if (r != ERR_NONE) {
	    X509_NAME_free(xn);
	    retval = r;
	    goto last;
	}

	if (coll_count >= 1000) {
	    fprintf(stderr, "Too many hash collisions: %s %s\n",
		    obj->type, fbase);
	    continue;
	}
	linkpathmax = strlen(obj->dirname) + 10 + strlen(obj->suffix) + 3 + 1;
	linkpath = (char *)malloc(linkpathmax);
	if (!linkpath) {
	    retval = ERR_NOMEM;
	    goto last;
	}
	BIO_snprintf(linkpath, linkpathmax, "%s/%08x.%s%d",
		obj->dirname, hash, obj->suffix, coll_count);
	linkbase = linkpath + strlen(obj->dirname) + 1;

	printf(" %s", linkbase);
	if (symlink(fbase, linkpath)) {
	    if (0
#ifdef EPERM
		    || errno == EPERM
#endif
#ifdef ENOTSUP
		    || errno == ENOTSUP
#endif
#ifdef EOPNOTSUPP
		    || errno == EOPNOTSUPP
#endif
#ifdef EINVAL
		    || errno == EINVAL
#endif
	       )
	    {
		int rr = copy_file(fpath, linkpath);
		if (rr == 1) perror(fbase);
		else if (rr == 2) perror(linkbase);
	    } else {
		perror(linkbase);
	    }
	}
	free(linkpath);
    }
    retval = ERR_NONE;
last:
    if (fp) fclose(fp);
    free(fpath);
    return retval;
}

err_type
read_pem_cert(X509_NAME **xn_ret, FILE *fp)
{
    X509 *x = PEM_read_X509_AUX(fp, NULL, NULL, NULL);
    X509_NAME *xn;
    *xn_ret = NULL;
    if (!x) return ERR_NONE;
    xn = *xn_ret = X509_NAME_dup(X509_get_subject_name(x));
    X509_free(x);
    if (!xn) return ERR_NOMEM;
    return ERR_NONE;
}

err_type
read_pem_crl(X509_NAME **xn_ret, FILE *fp)
{
    X509_CRL *crl = PEM_read_X509_CRL(fp, NULL, NULL, NULL);
    X509_NAME *xn;
    *xn_ret = NULL;
    if (!crl) return ERR_NONE;
    xn = *xn_ret = X509_NAME_dup(X509_CRL_get_issuer(crl));
    X509_CRL_free(crl);
    if (!xn) return ERR_NOMEM;
    return ERR_NONE;
}

int
copy_file(const char *src, const char *dst)
{
#if defined(COPY_FILE_USING_STDIO)
    int retval = 0;
    FILE *sfp = NULL, *dfp = NULL;
    sfp = fopen(src, "r");
    if (!sfp) {
	retval = 1;
	goto last;
    }
    dfp = fopen(dst, "w");
    if (!dfp) {
	retval = 2;
	goto last;
    }

    for (;;) {
	char buf[BUFSIZ];
	size_t readsize, writesize;

	readsize = fread(buf, 1, sizeof buf, sfp);
	if (readsize == 0) {
	    if (ferror(sfp)) {
		errno = EIO; /* XXX */
		retval = 1;
		goto last;
	    } else {
		break;
	    }
	}
	writesize = fwrite(buf, 1, readsize, dfp);
	if (writesize < readsize) {
	    errno = EIO; /* XXX */
	    retval = 2;
	    goto last;
	}
    }
last:
    if (dfp) fclose(dfp);
    if (sfp) fclose(sfp);
    return retval;
#else /* UNIX style */
    int sfd = -1, dfd = -1, retval = (int)0xdeadbeef;
    {
	sfd = open(src, O_RDONLY, 0);
	if (sfd < 0) {
	    retval = 1;
	    goto last;
	}
	dfd = open(dst, O_WRONLY | O_CREAT | O_EXCL, 0644);
	if (dfd < 0) {
	    retval = 2;
	    goto last;
	}
	for (;;) {
	    char buf[BUFSIZ];
	    const char *wp = buf;
	    ssize_t readsize = read(sfd, buf, sizeof buf);
	    if (readsize < 0) {
		retval = 1;
		goto last;
	    } else if (readsize == 0) {
		retval = 0;
		goto last;
	    }
	    while (wp < buf + readsize) {
		ssize_t writesize = write(dfd, wp, buf + readsize - wp);
		if (writesize < 0) {
		    retval = 2;
		    goto last;
		}
		wp += writesize;
	    }
	}
    }
    retval = 0;
last:
    if (sfd >= 0) close(sfd);
    if (dfd >= 0) close(dfd);
    return retval;
#endif
}

err_type
clean_dir(const char *dirname, unsigned int flags)
{
    err_type retval = ERR_NONE;
    DIR *dir = NULL;
    PtrArray *hashfiles = NULL;
    size_t i;
    struct dirent *entp;

    if (!(dir = opendir(dirname))) {
	retval = ERR_DIR_OPEN;
	goto last;
    }
    if (PtrArray_new(&hashfiles)) goto nomem;
    
    while ((entp = readdir(dir)) != NULL) {
	const char *fbase = entp->d_name, *p;
	char *fbase_copy = NULL;
	if (strlen(fbase) < 9
		|| strspn(fbase, "0123456789ABCDEFabcdef") != 8
		|| fbase[8] != '.')
	    continue;
	p = fbase + 9;
	if (*p == 'r') {
	    if (!(flags & OPT_DO_CRLS)) continue;
	    else ++p;
	} else {
	    if (!(flags & OPT_DO_CERTS)) continue;
	}
	if (!*p || strspn(p, "0123456789") != strlen(p))
	    continue;

	fbase_copy = BUF_strdup(fbase);
	if (!fbase_copy) goto nomem;
	if (PtrArray_add(hashfiles, fbase_copy)) {
	    free(fbase_copy);
	    goto nomem;
	}
    }

    for (i = 0; i < hashfiles->pa_size; ++i) {
	const char *fbase = hashfiles->pa_body[i];
	char *fpath = NULL;
	size_t fpathmax;

	fpathmax = strlen(dirname) + 1 + strlen(fbase) + 1;
	if (!(fpath = malloc(fpathmax))) goto nomem;
	BIO_snprintf(fpath, fpathmax, "%s/%s", dirname, fbase);
	if (unlink(fpath))
	    perror(fbase);
	free(fpath);
    }
    retval = ERR_NONE;
    goto last;
nomem:
    retval = ERR_NOMEM;
last:
    if (hashfiles) {
	for (i = 0; i < hashfiles->pa_size; ++i)
	    free(hashfiles->pa_body[i]);
	PtrArray_delete(hashfiles);
    }
    if (dir) closedir(dir);
    return retval;
}

err_type
process_dir(const char *dirname, unsigned int flags)
{
    err_type retval = ERR_NONE;
    DIR *dir = NULL;
    PtrArray *pemfiles = NULL;
    HashMaker *cert_hash_maker = NULL, *crl_hash_maker = NULL;
    size_t i;
    struct dirent *entp;

    printf("Doing %s\n", dirname);
    retval = clean_dir(dirname, flags);
    if (retval == ERR_DIR_OPEN) {
	perror(dirname);
	retval = ERR_NONE;
	goto last;
    } else if (retval) {
	goto last;
    }

    if (!(dir = opendir(dirname))) {
	perror(dirname);
	retval = ERR_NONE;
	goto last;
    }
    if (PtrArray_new(&pemfiles)) goto nomem;
    
    while ((entp = readdir(dir)) != NULL) {
	const char *fbase = entp->d_name;
	size_t fbaselen = strlen(fbase);
	char *fbase_copy = NULL;

	if (fbaselen < 5 || strcmp(fbase + fbaselen - 4, ".pem"))
	    continue;
	fbase_copy = BUF_strdup(fbase);
	if (!fbase_copy) goto nomem;
	if (PtrArray_add(pemfiles, fbase_copy)) {
	    free(fbase_copy);
	    goto nomem;
	}
    }

    if (flags & OPT_DO_CERTS) {
	retval = HashMaker_new(&cert_hash_maker, dirname, "", "certificate",
		&read_pem_cert);
	if (retval) goto last;
    }
    if (flags & OPT_DO_CRLS) {
	retval = HashMaker_new(&crl_hash_maker, dirname, "r", "CRL",
		&read_pem_crl);
	if (retval) goto last;
    }

    for (i = 0; i < pemfiles->pa_size; ++i) {
	const char *fbase = pemfiles->pa_body[i];

	printf("%s =>", fbase);
	if (flags & OPT_DO_CERTS) {
	    retval = HashMaker_hash_file(cert_hash_maker, fbase);
	    if (retval) goto last;
	}
	if (flags & OPT_DO_CRLS) {
	    retval = HashMaker_hash_file(crl_hash_maker, fbase);
	    if (retval) goto last;
	}
	printf("\n");
    }
    retval = ERR_NONE;
    goto last;
nomem:
    retval = ERR_NOMEM;
last:
    HashMaker_delete(crl_hash_maker);
    HashMaker_delete(cert_hash_maker);
    if (pemfiles) {
	for (i = 0; i < pemfiles->pa_size; ++i)
	    free(pemfiles->pa_body[i]);
	PtrArray_delete(pemfiles);
    }
    if (dir) closedir(dir);
    return retval;
}

void
usage(void)
{
    fprintf(stdout,
"usage: multi_c_rehash [options...] [--] [dirs...]\n\
options:\n\
    -certonly  rehash only certificates\n\
    -crlonly   rehash only CRLs\n\
    -version   print version\n\
    -help      print this help\n\
    -h         print this help\n\
");
}

err_type
main2(int argc, char *const argv[])
{
    err_type retval = ERR_NONE;
    const char *cert_dir_env;
    int arg = 1;
    unsigned int flags = OPT_DO_CERTS | OPT_DO_CRLS;

    for (; arg < argc && argv[arg][0] == '-'; ++arg) {
	const char *opt = argv[arg];
	if (!strcmp(opt, "-certonly"))
	    flags = OPT_DO_CERTS;
	else if (!strcmp(opt, "-crlonly"))
	    flags = OPT_DO_CRLS;
	else if (!strcmp(opt, "-version")) {
	    printf("multi_c_rehash 1.1\n");
	    goto last;
	} else if (!strcmp(opt, "-help") || !strcmp(opt, "-h")) {
	    usage();
	    goto last;
	} else if (!strcmp(opt, "--")) {
	    ++arg;
	    break;
	} else {
	    fprintf(stderr, "Bad option %s; try multi_c_rehash -h\n", opt);
	    retval = ERR_BADARG;
	    goto last;
	}
    }
    if (!(flags & (OPT_DO_CERTS | OPT_DO_CRLS))) {
	fprintf(stderr, "-certonly and -crlonly are mutually exclusive\n");
	retval = ERR_BADARG;
	goto last;
    }
    if (arg < argc) {
	for (; arg < argc; ++arg) {
	    retval = process_dir(argv[arg], flags);
	    if (retval) goto last;
	}
    } else if ((cert_dir_env = getenv("SSL_CERT_DIR")) != NULL
	    && *cert_dir_env != '\0') {
	char *work;
	size_t i, j;
	work = BUF_strdup(cert_dir_env);
	if (!work) {
	    retval = ERR_NOMEM;
	    goto last;
	}
	for (i = 0, j = 1; work[j]; ++j) {
	    if (work[j] == ':') {
		work[j] = '\0';
		if (i + 1 < j) {
		    retval = process_dir(&work[i], flags);
		    if (retval) goto envlast;
		}
		i = j = j + 1;
	    }
	}
	if (i + 1 < j) {
	    retval = process_dir(&work[i], flags);
	    if (retval) goto envlast;
	}
envlast:
	free(work);
    } else {
	retval = process_dir(CERTDIR, flags);
	if (retval) goto last;
    }
last:
    return retval;
}

void
print_error(const char *msg)
{ write(2, msg, strlen(msg)); }

int
main(int argc, char *const argv[])
{
    err_type r;
    if (argc == 0) {
	print_error("Bad excecution\n");
	return 2;
    }
    r = main2(argc, argv);
    if (r == ERR_NOMEM) {
	print_error("Out of memory\n");
	return 1;
    } else if (r == ERR_BADARG)
	return 1;
    assert(r == ERR_NONE);
    return 0;
}
